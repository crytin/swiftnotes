import UIKit

var str = "Hello, playground"
// var ####
// represents variable declarartion name. Type is not muttable.
// let #### is like const in C++ constant variable
// You can declare variable types with var name:Type. ex: name:String; name:Int; name:Double
var hello:String = "Hello World"
var lhs:Int = 10
var rhs = 2
var dec:Double = 4.2
let temp = 4
print(hello)
hello = String(24)
print(lhs + rhs)
print(lhs - rhs)
print(lhs / rhs)
print(lhs * rhs)
lhs += 4
print(lhs+temp)
lhs = temp
// temp += 3 should be an error because temp is a constant variable

// String(20) -> converts to a string
// Int(34.4) -> cuts off the decimal so like floor rounding
// round(34.4) -> does regular rounding to double and floats. Result is also depending on input


// If statements
// if CONDITION {}
// else if CONDITION {}
// else {}
// && == AND
// || == OR


// Check even

var test = 40
if test == 42{
    print("test is the special number")
}
else if test % 2 == 0{
    print("test is even")
}
else{
    print("test is not even")
}

// Switch Statements
// switch "some value to consider" {
// case "value1":
//     response
// case "value2", "value3":
//     response
// default: #like the else statement
//     do something else

let someChar:Character = "c"
switch someChar{
    case "a":
        print("The first letter of the alphabet")
    case "b", "c":
        print("Letter is either b or c")
    case "z":
        print("The last letter of the alphabet")
    default:
        print("Some other character")
}

// For Loop
// for i in lower...upper{
//     code
//}

// This format includes the 5
for i in 1...5{
    print(i)
}

print()

// Use stride to indicate interval
// stride(from: #, to: #, by: interval
// excludes the to statement

for i in stride(from: 0, to: 5, by: 1){
    print(i)
}
print()
// Print even numbers from 0 to 12

for i in stride(from: 0, to: 13, by: 2){
    print(i)
}

// While loop
// while condition{
//     do this
//}

var counter = 0
while counter < 5{
    print(counter)
    counter += 1
}

print()
// Repeat-While is just like a do while
// repeat{
//     do this
// } while condition

var rep = 1
repeat{
    print(rep)
    rep -= 1
} while rep != 0

// Functions
// func name(input: type) -> type (return){
//     code
// }
// call it with:
// name(input: ####)
// -> indicates return type if we are not returning anything we dont need ->

func doNothing(){
    print("I did nothing")
}

doNothing()

func addtwonumbers(a: Int, b: Int) -> Int{
    return a + b
}

print(addtwonumbers(a: 5,b: 6))
// print(addtwonumbers(b: 5,a: 6)) order matters

// Default Parameters, Implicit Return
// by default, parameters use their parameter name as their argument label
// In a function there are arguments parameter: type
// If _ or underscore is the argument, then we dont need to put param:###

// Implicit return happens when the entire body is a single expression no need to use return,
// it will return it automatically

func addtwo(a: Int, _ b: Int = 2, c: Int = 4) -> Int{
    a + b + c
}

print(addtwo(a:4,c: 9))
print(addtwo(a:4))

func add3num(_ a:Int, _ b:Int, _ c:Int) -> Int{
    a + b + c
}

print(add3num(1,2,3))

	
